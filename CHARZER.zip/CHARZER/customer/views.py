import uuid
from django.core.signing import Signer
from django.http import Http404
import urllib.request as urllib2
import urllib
from rest_framework.views import APIView
from rest_framework import generics
from hashlib import blake2b
import mysql.connector
import random
import string
import requests
import urllib.parse
from django.shortcuts import render, get_object_or_404
from rest_framework import viewsets, status
from .serializers import *
from .models import *
from django.db.models import Q
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter, SearchFilter
import json
# install passlib-1.7.4
from passlib.hash import pbkdf2_sha256

# gigj

# Create your views here.

mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password=''
)

# Charger API


class ChargerDetail(APIView):
    serializer_class = ChargeringStationSerialiser

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        charger = Charger.objects.all()
        return charger

    def get(self, request, *args, **kwargs):
        charger_id = request.query_params['charger_id']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):

            try:
                charger = Charger.objects.get(charger_id=charger_id)
            except Charger.DoesNotExist:
                return Response({"status": "charger not found"})
            serializer = ChargeringStationSerialiser(charger)
            return Response(serializer.data)
        else:
            return Response({
                "message": "invalid authkey"
            })


# Vehicle API

class VehicleList(APIView):
    serializer_class = VehicleSerialiser

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        vehicles = Vehicle.objects.all()
        return vehicles

    def get(self, request, *args, **kwargs):
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            try:
                customer = Customers.objects.get(customer_id=customer_id)
                vehicles = customer.vehicle_set.all()
            except Customers.DoesNotExist:
                return Response({"status": "customer not found"})
            if vehicles:
                serializer = VehicleSerialiser(vehicles, many=True)
                return Response(serializer.data)
            return Response({"status": "no vehicle available"})
        else:
            return Response({"status": "invalid authkey"})

# #
# # Details of an Vehicle
# #


class VehicleView(APIView):
    serializer_class = VehicleEditSerialiser

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        vehicle = Vehicle.objects.all()
        return vehicle

    def get(self, request, *args, **kwargs):
        vehicle_id = request.query_params['vehicle_id']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):

            try:
                vehicle = Vehicle.objects.get(
                    vehicle_id=vehicle_id)
            except Vehicle.DoesNotExist:
                return Response({"status": "not found"})
            serializer = VehicleEditSerialiser(vehicle)
            return Response(serializer.data)
        else:
            return Response({"status": "invalid authkey"})

    def put(self, request, *args, **kwargs):
        vehicle_id = request.query_params['vehicle_id']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            try:
                vehicle = Vehicle.objects.get(vehicle_id=vehicle_id)
            except Vehicle.DoesNotExist:
                return Response({"status": "not found"})
            serializer = VehicleEditSerialiser(vehicle, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"status": "invalid authkey"})

    def delete(self, request, *args, **kwargs):
        vehicle_id = request.query_params['vehicle_id']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            try:
                vehicle = Vehicle.objects.get(vehicle_id=vehicle_id)
            except Vehicle.DoesNotExist:
                return Response({"status": "not found"})
            vehicle.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        else:
            return Response({"status": "invalid authkey"})

    def post(self, request, format=None):
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            vehicle = VehicleEditSerialiser(data=request.data)
            if vehicle.is_valid():
                vehicle.save()
                return Response(vehicle.data, status=status.HTTP_201_CREATED)
            return Response(vehicle.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"status": "invalid authkey"})


# #
# # List of Appointments of a customer
# #
# class AppointmentList(APIView):
#     queryset = Appointment.objects.all()
#     serializer_class = AppointmentSerialiser

#     @classmethod
#     def get_extra_actions(cls):
#         return []

#     def get(self, request, *args, **kwargs):
#         customer_id = request.query_params['customer_id']

#         token = request.query_params['authkey']
#         try:
#             customer = Customers.objects.get(customer_id=customer_id)
#         except:
#             return Response({'message': 'invalid customer_id'})

#         if customer.verifyToken(token):
#             try:
#                 customer = Customers.objects.get(customer_id=customer_id)
#                 appointment = customer.appointment_set.all()
#             except Customers.DoesNotExist:
#                 return Response({"status": "customer not found"})
#             if appointment:
#                 serializer = AppointmentSerialiser(appointment, many=True)
#                 return Response(serializer.data)
#             return Response({"status": "no appointment available"})
#         else:
#             return Response({"status": "invalid authkey"})


# # #
# # # Details of an Apponiment ad edit
# # #


# class EditAppointment(APIView):
#     serializer_class = AppointmentEditSerialiser

#     @classmethod
#     def get_extra_actions(cls):
#         return []

#     def get_queryset(self):
#         chargers = Appointment.objects.all()
#         return chargers

#     def get(self, request, *args, **kwargs):
#         app_id = request.query_params['app_ID']
#         customer_id = request.query_params['customer_id']
#         token = request.query_params['authkey']
#         try:
#             customer = Customers.objects.get(customer_id=customer_id)
#         except:
#             return Response({'message': 'invalid customer_id'})

#         if customer.verifyToken(token):
#             try:
#                 appointment = Appointment.objects.get(
#                     app_id=app_id)
#             except Appointment.DoesNotExist:
#                 return Response({"status": "not found"})
#             serializer = AppointmentEditSerialiser(appointment)
#             return Response(serializer.data)
#         else:
#             return Response({"status": "invalid authkey"})

#     def put(self, request, *args, **kwargs):
#         app_id = request.query_params['app_ID']
#         customer_id = request.query_params['customer_id']
#         token = request.query_params['authkey']
#         try:
#             customer = Customers.objects.get(customer_id=customer_id)
#         except:
#             return Response({'message': 'invalid customer_id'})

#         if customer.verifyToken(token):
#             try:
#                 appointment = Appointment.objects.get(
#                     app_id=app_id)
#             except Appointment.DoesNotExist:
#                 return Response({"status": "not found"})
#             serializer = AppointmentEditSerialiser(
#                 appointment, data=request.data)
#             if serializer.is_valid():
#                 serializer.save()
#                 return Response(serializer.data)
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"status": "invalid authkey"})

#     def delete(self, request, *args, **kwargs):
#         app_id = request.query_params['app_ID']
#         customer_id = request.query_params['customer_id']
#         token = request.query_params['authkey']
#         try:
#             customer = Customers.objects.get(customer_id=customer_id)
#         except:
#             return Response({'message': 'invalid customer_id'})

#         if customer.verifyToken(token):
#             try:
#                 appointment = Appointment.objects.get(
#                     app_id=app_id)
#             except Appointment.DoesNotExist:
#                 return Response({"status": "not found"})
#             appointment.delete()
#             return Response(status=status.HTTP_204_NO_CONTENT)
#         else:
#             return Response({"status": "invalid authkey"})

#     def post(self, request, format=None):
#         customer_id = request.query_params['customer_id']
#         token = request.query_params['authkey']
#         try:
#             customer = Customers.objects.get(customer_id=customer_id)
#         except:
#             return Response({'message': 'invalid customer_id'})

#         if customer.verifyToken(token):
#             appointment = AppointmentEditSerialiser(data=request.data)
#             if appointment.is_valid():
#                 appointment.save()
#                 return Response(appointment.data, status=status.HTTP_201_CREATED)
#             return Response(appointment.errors, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"status": "invalid authkey"})


# class Appointments(APIView):
#     serializer_class = AppointmentSerialiser

#     @classmethod
#     def get_extra_actions(cls):
#         return []

#     def get_queryset(self):
#         chargers = Appointment.objects.all()
#         return chargers

#     def get(self, request, *args, **kwargs):
#         app_id = request.query_params['app_ID']
#         customer_id = request.query_params['customer_id']
#         token = request.query_params['authkey']
#         try:
#             customer = Customers.objects.get(customer_id=customer_id)
#         except:
#             return Response({'message': 'invalid customer_id'})

#         if customer.verifyToken(token):
#             try:
#                 appointment = Appointment.objects.get(
#                     app_id=app_id)
#             except Appointment.DoesNotExist:
#                 return Response({"status": "not found"})
#             serializer = AppointmentSerialiser(appointment)
#             return Response(serializer.data)
#         else:
#             return Response({"status": "invalid authkey"})

# #
# # Bookmark APIViews
# #


class BookmarkList(generics.ListAPIView):
    # queryset = FavouriteCharger.objects.all()
    serializer_class = BookmarkSerialiser

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        chargers = FavouriteCharger.objects.all()
        return chargers

    def get(self, request, *args, **kwargs):
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            try:
                customer = Customers.objects.get(customer_id=customer_id)
                chargers = customer.favouritecharger_set.all()
            except:
                return Response({"status": "customer not found"})
            if chargers:
                serializer = BookmarkSerialiser(chargers, many=True)
                return Response(serializer.data)
            return Response({"status": "no bookmark available"})

        else:
            return Response({"status": "invalid authkey"})

#
# give a charger that is bookmarked
#


class BookmarkCharger(APIView):
    serializer_class = BookmarkSerialiser

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        chargers = FavouriteCharger.objects.all()
        return chargers

    def get(self, request, *args, **kwargs):
        bookmark_id = request.query_params['favourite_ID']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            try:
                charger = FavouriteCharger.objects.get(
                    favourite_ID=bookmark_id)
            except FavouriteCharger.DoesNotExist:
                return Response({"status": "not found"})
            serializer = BookmarkSerialiser(charger)
            return Response(serializer.data)
        else:
            return Response({"status": "invalid authkey"})


class EditBookmarkCharger(APIView):
    serializer_class = BookmarkEditSerialiser

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        chargers = FavouriteCharger.objects.all()
        return chargers

    def get(self, request, *args, **kwargs):
        bookmark_id = request.query_params['favourite_ID']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            try:
                charger = FavouriteCharger.objects.get(
                    favourite_ID=bookmark_id)
            except FavouriteCharger.DoesNotExist:
                return Response({"status": "not found"})
            serializer = BookmarkEditSerialiser(charger)
            return Response(serializer.data)
        else:
            return Response({"status": "invalid authkey"})

    def put(self, request, *args, **kwargs):
        bookmark_id = request.query_params['favourite_ID']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            try:
                charger = FavouriteCharger.objects.get(
                    favourite_ID=bookmark_id)
            except FavouriteCharger.DoesNotExist:
                return Response({"status": "not found"})
            serializer = BookmarkEditSerialiser(charger, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"status": "invalid authkey"})

    def delete(self, request, *args, **kwargs):
        bookmark_id = request.query_params['favourite_ID']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})
        if customer.verifyToken(token):
            try:
                charger = FavouriteCharger.objects.get(
                    favourite_ID=bookmark_id)
            except FavouriteCharger.DoesNotExist:
                return Response({"status": "not found"})
            charger.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        else:
            return Response({"status": "invalid authkey"})

    def post(self, request, format=None):

        customer_id = request.query_params['customer_id']

        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)

        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            bookmark = BookmarkEditSerialiser(data=request.data)
            if bookmark.is_valid():
                bookmark.save()
                return Response(bookmark.data, status=status.HTTP_201_CREATED)
            return Response(bookmark.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"status": "invalid authkey"})
# coupon Api


class GetCoupons(APIView):

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        coupons = Coupon.objects.all()
        return coupons

    def get(self, request, *args, **kwargs):
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            coupons = Coupon.objects.all()
            serializer = CouponSerializer(coupons, many=True)
            return Response(serializer.data)
        else:
            return Response({"status": "invalid authkey"})


# # billing Apis


# class CreateBill(APIView):
#     @classmethod
#     def get_extra_actions(cls):
#         return []

#     def get_queryset(self):
#         bills = Bill_Details.objects.all()
#         return bills

#     def post(self, request, *args, **kwargs):
#         appointment = request.query_params.get('app_id')
#         coupon = request.query_params.get('coupon_id', False)
#         bank_transaction = request.query_params.get('bank_transaction')
#         bill_ticket_number = request.query_params.get('bill_ticket_number')
#         customer_id = request.query_params.get('customer_id')
#         token = request.query_params['authkey']
#         try:
#             customer = Customers.objects.get(customer_id=customer_id)
#             app = Appointment.objects.get(app_id=appointment)
#             app_amt = app.app_pay
#             coupon_amt = 0
#             if coupon:
#                 coupon = Coupon.objects.get(coupon_id=coupon)
#                 coupon_amt = coupon.coupon_amt
#         except:
#             return Response({'message': 'invalid data'})

#         if customer.verifyToken(token):
#             bill_data = {
#                 'bill_amount': app_amt-coupon_amt,
#                 'bank_transaction': bank_transaction,
#                 'coupon': coupon,
#                 'bill_ticket_number': bill_ticket_number,
#                 'bill_app': app,
#                 'bill_host': app.app_charger.charger_host
#             }
#             serializer = BillingCreateSerialiser(data=bill_data)
#             if serializer.is_valid():
#                 serializer.save()
#                 app.app_success = True
#                 app.save()
#                 return Response(serializer.data, status=status.HTTP_201_CREATED)
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response({"status": "invalid authkey"})

# # class CustomerViewSet(APIView):
# #     # queryset = Customers.objects.all()
# #     # serializer_class = CustomerSerialiser

# #     @classmethod
# #     def get_extra_actions(cls):
# #         return []

# #     def get_queryset(self):
# #         customer = Customers.objects.all()
# #         return customer

#     # def get(self, request, *args, **kwargs):
#     #     customer_id = request.query_params['customer_id']
#     #     token = request.query_params['authkey']
#     #     try:
#     #         customer = Customers.objects.get(customer_id=customer_id)
#     #     except:
#     #         return Response({'message': 'invalid customer_id'})

#     #     if customer.verifyToken(token):

#     #         queryset = self.get_queryset()
#     #         if queryset:
#     #             serializer = CustomerSerialiser(queryset, many=True)
#     #             return Response(serializer.data)
#     #         return Response({"status": "no customer found"})
#     #     else:
#     #         return Response({"status":"invalid authkey"})

# # #
# # # customer profile
# # #


class Profile(APIView):
    serializer_class = EditCustomerProfileSerializer

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        customer = Customers.objects.all()
        return customer

    def get(self, request, *args, **kwargs):

        id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=id)
        except Customers.DoesNotExist:
            return Response({"status": "not found"})
        customer_id = request.query_params['customer_id']
        if customer.verifyToken(token):
            serializer = GetCustomerSerializer(customer)
            return Response(serializer.data)
        else:
            return Response({"status": "invalid authkey"})

    def put(self, request, *args, **kwargs):
        id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=id)
        except Customers.DoesNotExist:
            return Response({"status": "not found"})
        if customer.verifyToken(token):
            serializer = EditCustomerProfileSerializer(
                customer, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({"status": "invalid authkey"})

# # #
# # # To get, check referal id and update the credits
# # #


class Referal(APIView):
    # queryset = Customers.objects.all()
    # serializer_class = CustomerSerialiser

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        customers = Customers.objects.all()
        return customers

    def put(self, request, *args, **kwargs):
        referalID = request.query_params['referalID']
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            credit = CreditType.objects.get(credit_name='Refer')
            amt = credit.credit_amt
            customer = Customers.objects.get(customer_id=customer_id)
            if customer.customer_referal == referalID:
                return Response({"status": "Invalid referal ID "})

            try:
                customer_refered = Customers.objects.exclude(
                    customer_id=customer_id).get(customer_referal=referalID)

            except Customers.DoesNotExist:
                return Response({"status": "Invalid referal ID "})
            customer.customer_credits += amt
            customer_refered.customer_credits += amt
            customer.save()
            customer_refered.save()
            credit_detail = Credit.objects.create(
                credit_customer=customer, credit_type=credit, credit_status=True)
            refered_credit_detail = Credit.objects.create(
                credit_customer=customer_refered, credit_type=credit, credit_status=True)
            credit_detail.save()
            refered_credit_detail.save()

            return Response({"status": "valid referal ID "})
        else:
            return Response({"status": "invalid authkey"})


# otp verification


class ValidatePhoneSendOTP(APIView):
    # serializer_class = VerificationSerialiser
    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        phone = PhoneOTP.objects.all()
        return phone

    def post(self, request, *args, **kwargs):
        authkey = "266785AMp0UB2Tv55f85d9fcP1"
        mobiles = request.data.get('phone')
        message = urllib.parse.quote("CHARZER OTP is: ")
        Secret_hash = b'asd2c1fsa25s'
        h = blake2b(digest_size=16, person=Secret_hash)
        sender = "CHARZER"
        if mobiles:
            phone = str(mobiles)
            mobile = str(mobiles).encode(encoding='UTF-8')
            h.update(mobile)

            try:
                customer = Customers.objects.get(customer_phone=phone)
            except Customers.DoesNotExist:
                pass
            key = send_otp(phone)
            if key:
                try:
                    old = PhoneOTP.objects.get(phone=phone)
                except:
                    obj = PhoneOTP.objects.create(
                        phone=phone
                    )
                    url = f"""http://api.msg91.com/api/v2/sendsms?authkey={authkey}&mobiles={mobiles}&message={message}{key}&sender={sender}&route=4&country=91"""

                    response = requests.get(url)
                    output = json.loads(response.text)

                    if output["type"] == 'success':

                        obj.otp_session_id = generate(phone)
                        obj.otp = key
                        obj.save()

                        return Response({

                            'status': True,
                            'detail': 'OTP sent successfully'
                        })
                    else:
                        return Response({
                            'status': False,
                            'detail': 'OTP sending Failed'
                        })

                if old:
                    count = old.count
                    if count > 10:
                        return Response({
                            'status': False,
                            'detail': 'Sending otp error. Limit Exceeded. Please Contact Customer support'
                        })

                    old.count = count + 1
                    old.save()

                    url = f"""http://api.msg91.com/api/v2/sendsms?authkey={authkey}&mobiles={mobiles}&message={message}{key}&sender={sender}&route=4&country=91"""
                    response = requests.get(url)
                    output = json.loads(response.text)

                    if output["type"] == 'success':

                        old.otp = key
                        old.save()

                        return Response({
                            'status': True,
                            'detail': 'OTP sent successfully'
                        })
                    else:
                        return Response({
                            'status': False,
                            'detail': 'OTP sending Failed'
                        })

                else:
                    return Response({
                        'status': False,
                        'detail': 'Sending otp error'
                    })

        else:
            return Response({
                'status': False,
                'detail': 'Phone number is not given in post request'
            })


def send_otp(phone):
    if phone:
        key = random.randint(999, 9999)
        print(key)
        return key
    else:
        return False


def generate(phone):
    if phone:
        length = random.randint(0, 75)
        key = pbkdf2_sha256.encrypt(phone)
        key = str(key)
        token = key[length:(length+15)]+str(uuid.uuid4().hex[:5])
        return token


# for registeration


class ValidateOTP(APIView):
    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        phone = PhoneOTP.objects.all()
        return phone

    def post(self, request, *args, **kwargs):
        phone = request.data.get('phone', False)
        otp_sent = request.data.get('otp', False)
        phone = str(phone)
        if phone and otp_sent:
            try:
                old = PhoneOTP.objects.get(phone=phone)

            except:
                return Response({
                    'status': False,
                    'detail': 'First Proceed via sending otp request'
                })

            if old.otp == str(otp_sent):

                try:
                    customer = Customers.objects.get(customer_phone=phone)
                    token = old.otp_session_id
                    customer.customer_token = pbkdf2_sha256.encrypt(token)
                    customer.save()
                    old.delete()
                    # customer = Customers.objects.get(customer_phone=phone)
                    return Response({
                        'authKey': token,
                        'customer id': customer.customer_id,
                        'status': True,
                        'detail': 'Customer logged in',

                    })
                except:
                    token = pbkdf2_sha256.encrypt(old.otp_session_id)
                    referralID = get_referral_id(old.phone)

                    customer_data = {
                        "customer_name": "User Name",
                        "customer_phone": old.phone,
                        "customer_referal": referralID,
                        "customer_token": token

                    }
                    serializer = CustomerSerialiser(data=customer_data)
                    if serializer.is_valid():
                        otp_session_id = old.otp_session_id
                        old.save()
                        serializer.save()
                        old.delete()
                        customer = Customers.objects.get(customer_phone=phone)
                        return Response({
                            'authkey': otp_session_id,
                            'customer id': customer.customer_id,
                            'status': True,
                            'detail': 'OTP MATCHED.User Registered '
                        })
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({
                    'status': False,
                    'detail': 'OTP INCORRECT'
                })

        else:
            return Response({
                'status': False,
                'detail': 'Please provide both phone and otp for Validation'
            })


def get_referral_id(phone):
    if phone:
        phone = int(phone)
        length = random.randint(1, 10)
        phone = phone*length
        key = hex(phone).lstrip("0x").rstrip("L")
        return key


# # Filter Charger


class Filter(APIView):

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        charger = Charger.objects.all()
        return charger

    def get(self, request, *args, **kwargs):
        power = request.query_params.get('power', '')
        socket = request.query_params.get('socket', '')
        amenities = request.query_params.get('amenities', '')
        parking = request.query_params.get('parking', '')
        networks = request.query_params.get('networks', '')
        distance = request.query_params.get('distance', '')
        latitude = request.query_params.get('latitude', '')
        longitude = request.query_params.get('longitude', '')
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):

            match = Charger.objects.filter(Q(power_available__icontains=power) & Q(
                Other_details__icontains=amenities) & Q(Other_details__icontains=parking) & Q(Other_details__icontains=networks))

            if socket:
                sockets = ChargerSocket.objects.filter(
                    socket_type__socket_name=socket)
                match = socket.charger_set.filter(Q(power_available__icontains=power) & Q(
                    Other_details__icontains=amenities) & Q(Other_details__icontains=parking) & Q(Other_details__icontains=networks))

            if distance != 0 and latitude and longitude:
                distance = int(distance)
                latitude = float(latitude)
                longitude = float(longitude)
                b = 2
                c = 3
                d = 5
                if distance <= b:
                    distance = 0.006
                elif b < distance <= c:
                    distance = 0.02
                elif c < distance <= d:
                    distance = 0.04
                elif d < distance:
                    distance = 0.2
                min_lat = latitude - distance
                max_lat = latitude + distance
                min_lng = longitude - distance
                max_lng = longitude + distance

                match = Charger.objects.filter(Q(power_available__icontains=power) & Q(charger_latitude__gt=min_lat, charger_latitude__lt=max_lat,
                                                                                       charger_longitude__gt=min_lng, charger_longitude__lt=max_lng) & Q(Other_details__icontains=amenities) & Q(Other_details__icontains=parking) & Q(Other_details__icontains=networks))

                if socket:
                    sockets = ChargerSocket.objects.filter(
                        socket_type__socket_name=socket)
                    match = socket.charger_set.filter(Q(power_available__icontains=power) & Q(charger_latitude__gt=min_lat, charger_latitude__lt=max_lat,
                                                                                              charger_longitude__gt=min_lng, charger_longitude__lt=max_lng) & Q(Other_details__icontains=amenities) & Q(Other_details__icontains=parking) & Q(Other_details__icontains=networks))

            serializer = ChargeringStationSerialiser(match, many=True)
            return Response(serializer.data)
        else:
            return Response({"status": "invalid authkey"})


class LogOut(generics.ListAPIView):

    @classmethod
    def get_extra_actions(cls):
        return []

    def get_queryset(self):
        chargers = Customers.objects.all()
        return chargers

    def get(self, request, *args, **kwargs):
        customer_id = request.query_params['customer_id']
        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})

        if customer.verifyToken(token):
            customer.customer_token = "**"
            customer.save()
            return Response({
                'status': True,
                'detail': 'Logged out successfully'
            })
        else:
            return Response({"status": "invalid authkey"})


class Subscribe(APIView):
    @classmethod
    def get_extra_actions(cls):
        return []

    def post(self, request, *args, **kwargs):
        customer_id = request.query_params['customer_id']
        subscription_type = request.query_params['type']

        token = request.query_params['authkey']
        try:
            customer = Customers.objects.get(customer_id=customer_id)
        except:
            return Response({'message': 'invalid customer_id'})
        if customer.verifyToken(token):
            try:
                subs_type = SubscriptionType.objects.get(
                    s_type=subscription_type)

            except:
                return Response({'message': 'invalid subscription Type'})
            customer.subscription = subs_type
            customer.save()
            return Response({'status': True,
                             'detail': 'Subscrition Active'})
