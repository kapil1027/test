from rest_framework import serializers
from .models import *


# All


class CustomerSerialiser(serializers.ModelSerializer):

    class Meta:
        model = Customers
        fields = "__all__"


class BookmarkEditSerialiser(serializers.ModelSerializer):

    class Meta:
        model = FavouriteCharger
        fields = "__all__"


class AppointmentEditSerialiser(serializers.ModelSerializer):

    class Meta:
        model = Appointment
        fields = "__all__"


class VehicleSerialiser(serializers.ModelSerializer):

    class Meta:
        model = Vehicle
        fields = "__all__"


class BillingCreateSerialiser(serializers.ModelSerializer):
    class Meta:
        model = Bill_Details
        fields = "__all__"


class CouponSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bill_Details
        fields = "__all__"


class SubscriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubscriptionType
        fields = "__all__"


class EditCustomerProfileSerializer(serializers.ModelSerializer):

    class Meta:
        model = Customers
        fields = ('customer_name', 'customer_email',
                  'customer_phone', 'customer_image', 'customer_address')


class GetCustomerSerializer(serializers.ModelSerializer):
    subscription = SubscriptionSerializer(read_only=True)

    class Meta:
        model = Customers
        fields = ('customer_name', 'customer_email',
                  'customer_phone', 'customer_image', 'customer_address', 'customer_credits', 'customer_active', 'customer_referal', 'subscription')


class ChargerHostSerialiser(serializers.ModelSerializer):
    class Meta:
        model = Host
        fields = ['host_name', 'host_address']


# class SocketType(serializers.ModelSerializer):
    

class ChargerSocketSerialiser(serializers.ModelSerializer):
    class Meta:
        model = ChargerSocket
        fields = "__all__"


class ChargeringStationSerialiser(serializers.ModelSerializer):
    Sockets = ChargerSocketSerialiser(many=True)
    charger_host = ChargerHostSerialiser()

    class Meta:
        model = Charger
        fields = ('charger_id', 'charger_name', 'charger_longitude', 'charger_latitude', 'charger_avaliability',
                  'charger_rating',  'charger_brand_logo', 'charger_host', 'power_available', 'Other_details', 'Sockets')


class BookmarkSerialiser(serializers.ModelSerializer):
    favourite_charger = ChargeringStationSerialiser(
    )

    class Meta:
        model = FavouriteCharger
        fields = ('favourite_ID', 'favourite_charger',
                  'favourite_customer')


# class AppointmentSerialiser(serializers.ModelSerializer):
#     app_customer = CustomerSerialiser()
#     app_charger = ChargeringStationSerialiser()

#     class Meta:
#         model = Appointment
#         fields = ('app_customer', 'app_charger',
#                   'app_date_time', 'app_create_date', 'app_create_time',  'app_duration', 'app_pay', 'app_success')


class VehicleEditSerialiser(serializers.ModelSerializer):

    class Meta:
        model = Vehicle
        fields = ('vehicle_number',
                  'vehicle_type', 'is_favourite')


class ReferalSerializer(serializers.ModelSerializer):

    class Meta:
        model = Customers
        field = ['customer_referal', 'customer_credits']
# class VerificationSerialiser(serializers.ModelSerializer):
#     class Meta:
#         model = PhoneOTP
#         fields = ['phone']
