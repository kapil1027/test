
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from passlib.hash import pbkdf2_sha256


class SubscriptionType(models.Model):
    def __str__(self):
        return self.s_type+" Subscription"
    s_type_id = models.AutoField(primary_key=True)
    s_type = models.CharField(max_length=100)
    s_title = models.CharField(max_length=100)
    s_description = models.CharField(max_length=100)
    s_price_pm = models.IntegerField(default=0)


class Customers(models.Model):
    def __str__(self):
        return self.customer_name

    customer_id = models.AutoField(primary_key=True)
    customer_name = models.CharField(max_length=100, default="User Name")
    email_regex = RegexValidator(
        regex=r'^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$', message="Not a valid email")
    customer_email = models.CharField(max_length=100, validators=[
                                      email_regex], blank=True, null=True)

    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,10}$', message="Phone number must be entered in the format +919999999999. Up to 10 digits allowed.")
    customer_phone = models.CharField('Phone', validators=[
        phone_regex], max_length=10, unique=True, default="")
    customer_image = models.ImageField(
        upload_to='images/')
    customer_address = models.CharField(
        max_length=100, default="", blank=True, null=True)
    customer_credits = models.FloatField(max_length=200, default=0)
    customer_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    customer_referal = models.CharField(
        max_length=100, default='', unique=True)
    subscription = models.ForeignKey(
        SubscriptionType, on_delete=models.CASCADE, blank=True, null=True)
    customer_token = models.CharField(max_length=300, default='**')

    def verifyToken(self, token):
        return pbkdf2_sha256.verify(token, self.customer_token)


class PhoneOTP(models.Model):
    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,10}$', message="Phone number must be entered in the format +919999999999. Up to 14 digits allowed.")
    phone = models.CharField(
        validators=[phone_regex], max_length=17, unique=True)
    otp = models.CharField(max_length=9, blank=True, null=True)
    count = models.IntegerField(default=0, help_text='Number of otp_sent')
    validated = models.BooleanField(
        default=False, help_text='If it is true, that means user have validate otp correctly in second API')
    otp_session_id = models.CharField(max_length=120, null=True, default="")

    def __str__(self):
        return str(self.phone)


class Vehicle(models.Model):
    def __str__(self):
        return self.vehicle_type+" "+self.vehicle_number

    vehicle_id = models.AutoField(primary_key=True)
    vehicle_image = models.ImageField(
        upload_to='images/')
    vehicle_customer = models.ForeignKey(
        Customers,  on_delete=models.CASCADE)
    vehicle_number = models.CharField(max_length=100)
    vehicle_type = models.CharField(max_length=100)
    is_favourite = models.BooleanField(default=True)


class Host(models.Model):
    def __str__(self):
        return self.host_name

    host_id = models.AutoField(primary_key=True)
    host_name = models.CharField(max_length=100, default='Host')
    hemail_regex = RegexValidator(
        regex=r'^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$', message="Not a valid email")
    host_email = models.CharField(max_length=100, validators=[
        hemail_regex], blank=True, null=True)
    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,10}$', message="Phone number must be entered in the format +919999999999. Up to 10 digits allowed.")
    host_phone = models.CharField('Phone', validators=[
        phone_regex], max_length=10, unique=True, default="")
    host_image = models.ImageField(
        upload_to='images/')
    host_address = models.CharField(
        max_length=100, default="", blank=True, null=True)
    host_credit = models.IntegerField(default=0)
    host_active = models.BooleanField(default=True)
    host_referal = models.CharField(max_length=100, default='', unique=True)
    host_token = models.CharField(max_length=100, default='**')

    def verifyToken(self, token):
        return pbkdf2_sha256.verify(token, self.host_token)


class SocketType(models.Model):
    def __str__(self):
        return self.socket_name
    socket_id = models.AutoField(primary_key=True)
    socket_name = models.CharField(max_length=100, default="")
    socket_image = models.ImageField(
        upload_to='images/')


class Charger(models.Model):
    def __str__(self):
        return self.charger_name
    charger_id = models.AutoField(primary_key=True)
    charger_name = models.CharField(max_length=100)
    charger_longitude = models.FloatField()
    charger_latitude = models.FloatField()
    charger_avaliability = models.CharField(max_length=100, default='')
    charger_rating = models.FloatField(default=0.0)

    charger_brand_logo = models.ImageField(
        upload_to='images/')
    charger_host = models.ForeignKey(Host,
                                     on_delete=models.CASCADE)
    power_available = models.CharField(max_length=100, default='')
    Other_details = models.CharField(max_length=100, default='')

    @ property
    def noOfBooking(self):
        app = self.appointment_set.all()
        noOfBooking = app.count()
        return noOfBooking

    @ property
    def Sockets(self):
        socket = self.chargersocket_set.all()
        return socket


class ChargerSocket(models.Model):
    charger_id = models.ForeignKey(Charger,
                                   on_delete=models.CASCADE, blank=True, null=True)
    socket_type = models.ForeignKey(SocketType,
                                    on_delete=models.CASCADE, blank=True, null=True)
    hour_price = models.FloatField(default=0.0)
    KWh_price = models.FloatField(default=0.0)
    charger_capacity = models.IntegerField()
    Socket_availabile = models.IntegerField(default=0)


class Coupon(models.Model):
    def __str__(self):
        return self.coupon_code
    coupon_id = models.AutoField(primary_key=True)
    coupon_code = models.CharField(max_length=50, default='')
    coupon_amt = models.IntegerField(default=0)
    valid_date = models.DateTimeField()
    customer_limit = models.IntegerField(default=0)
    open_to = [('All', 'All'), ('Nobody',
                                'Nobody'), ('selected_customer_type_only', 'Selected customer type only')]


class CreditType(models.Model):
    def __str__(self):
        return self.credit_name
    credit_name = models.CharField(max_length=100, default="")
    credit_amt = models.FloatField(default=0.0)


class Credit(models.Model):
    def __str__(self):
        return str(self.credit_customer) + str(self.credit_type)
    credit_id = models.AutoField(primary_key=True)
    credit_customer = models.ForeignKey(
        Customers, on_delete=models.CASCADE)
    credit_type = models.ForeignKey(
        CreditType, on_delete=models.CASCADE)
    # status: True means credit was increased, false means credit was decreased
    credit_status = models.BooleanField(default=True)


class Photo(models.Model):
    charger_photo = models.ImageField(
        upload_to='images/')
    Charger_id = models.ForeignKey(
        Charger, on_delete=models.CASCADE)


class FavouriteCharger(models.Model):
    def __str__(self):
        return str(self.favourite_customer)

    favourite_ID = models.AutoField(primary_key=True)
    favourite_charger = models.ForeignKey(
        Charger, on_delete=models.CASCADE)
    favourite_customer = models.ForeignKey(
        Customers,  on_delete=models.CASCADE)


class Appointment(models.Model):
    def __str__(self):
        return "APP"+str(self.app_customer)+"/"+str(self.app_id)
    app_id = models.AutoField(primary_key=True)
    app_customer = models.ForeignKey(
        Customers, on_delete=models.CASCADE)
    app_charger = models.ForeignKey(
        Charger,  on_delete=models.CASCADE)
    app_date_time = models.DateTimeField(blank=True, null=True)
    app_create_date = models.DateField(auto_now_add=True)
    app_create_time = models.TimeField(auto_now_add=True)
    app_duration = models.FloatField(max_length=100)
    # app_pay = models.FloatField(max_length=100)
    app_status = [('Completed', 'Completed'), ('Upcommping',
                                               'Upcommping'), ('Cancelled', 'Cancelled'), ('pending', 'pending')]
    app_socket = models.ForeignKey(
        ChargerSocket, on_delete=models.CASCADE, blank=True, null=True)


class Bill_Details(models.Model):
    def __str__(self):
        return "BILL"+str(self.bill_id)

    bill_id = models.AutoField(primary_key=True)
    bill_date = models.DateField(auto_now_add=True)
    bill_time = models.TimeField(auto_now_add=True)
    bill_amount = models.FloatField(max_length=100)
    bank_transaction = models.CharField(max_length=100, default="")
    bill_ticket_number = models.IntegerField()
    bill_app = models.ForeignKey(
        Appointment, on_delete=models.CASCADE)
    coupon = models.ForeignKey(
        Coupon, on_delete=models.CASCADE, blank=True, null=True)
    bill_host = models.ForeignKey(
        Host, on_delete=models.CASCADE, blank=True, null=True)


class SubAdmin(models.Model):
    subadmin = models.OneToOneField(
        User, on_delete=models.CASCADE, default=1)
    subadmin_email = models.CharField(max_length=100)
    subadmin_active = models.FloatField()

    def __str__(self):
        return self.user.username


class SubAdminAccess(models.Model):
    access_id = models.AutoField(primary_key=True)
    edit_user = models.BooleanField(default=False)
    edit_host = models.BooleanField(default=False)
    edit_billdetails = models.BooleanField(default=False)
    edit_pumpdetails = models.BooleanField(default=False)
    edit_appointments = models.BooleanField(default=False)
    access_subadmin = models.ForeignKey(
        SubAdmin,   on_delete=models.CASCADE)


class BannerAds(models.Model):
    def __str__(self):
        return "ad"+self.banner_id
    banner_id = models.AutoField(primary_key=True)
    banner_subadmin_id = models.ForeignKey(
        SubAdmin, on_delete=models.CASCADE)
    file_path = models.ImageField(
        upload_to='images/')
