# from django.urls import path, include
# from django.conf.urls import url
# from . import views
# from rest_framework import routers
# from .serializers import *
# # from .models import *
# from rest_framework.urlpatterns import format_suffix_patterns


# app_name = 'host'
# urlpatterns = [
#     url('BookingHost/', views.BookingHost.as_view()),
#     url('HostProfile/', views.Profile.as_view()),
#     url('AllAppointments/', views.HostAppointmentList.as_view()),
#     url('ChargerAppointments/', views.ChargerAppointmentList.as_view()
#         ),
#     url('MyEarning/', views.MyEarning.as_view()),

#     # OTP
#     url('SendOtp/', views.ValidatePhoneSendOTP.as_view()),
#     url('VerifyOtp/', views.ValidateOTP.as_view()),
#     url('Logout/', views.LogOut.as_view()),
# ]
# urlpatterns = format_suffix_patterns(urlpatterns)
