# from customer.models import *
# from customer.serializers import *


# class HostSerialiser(serializers.ModelSerializer):
#     class Meta:
#         model = Host
#         fields = "__all__"


# class ChargerListSerializer(serializers.ModelSerializer):
#     charger_socket = ChargerSocketSerialiser()
#     charger_host = HostSerialiser()
#     noOfBooking = serializers.ReadOnlyField(default=0)

#     class Meta:
#         model = Charger
#         fields = ('charger_id', 'charger_name', 'charger_longitude', 'charger_latitude', 'charger_avaliability', 'charger_capacity',
#                   'charger_rate', 'charger_socket', 'charger_socket_amt', 'charger_brand_logo', 'charger_host', 'power_available',  'Other_details', 'noOfBooking',)


# class BillingViewSerialiser(serializers.ModelSerializer):
#     coupon = CouponSerializer()
#     bill_app = AppointmentSerialiser()
#     totalCredit = serializers.FloatField()

#     class Meta:
#         model = Bill_Details
#         fields = ('bill_id', 'bill_date', 'bill_time', 'bill_amount',
#                   'bank_transaction', 'coupon', 'bill_ticket_number', 'bill_app__app_customer', 'bill_app__app_charger')


# class CreateCharger(serializers.ModelSerializer):
#     class Meta:
#         model = Charger
#         field = "__all__"
